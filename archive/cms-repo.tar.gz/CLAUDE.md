# CMS 고도화 Master

> 이 문서는 AI 에이전트의 프로젝트 컨텍스트 파일이다. 파일명(`CLAUDE.md`)은 자동 인식 규약이므로 변경하지 말 것.

## 프로젝트 개요

대교(Daekyo) 교육 콘텐츠 관리 시스템(CMS) 고도화 프로젝트.
단일 HTML 파일로 구현된 인터랙티브 프로토타입이며, 실제 개발 전 UX/워크플로우 검증 목적.

- **담당자**: Shawn (sangcheol.kim@daekyo.co.kr)
- **기술 스택**: 단일 HTML + Vanilla JS + CSS (외부 라이브러리 없음)
- **파일 크기**: ~1MB+
- **현재 버전**: `cms_stg_prd_v7.html`

---

## 핵심 파일 구조

```
/sessions/lucid-busy-hamilton/
├── cms_prototype.html              ← 작업용 원본 (여기서 편집)
├── mnt/Prototype/
│   ├── cms_stg_prd_v7.html         ← 최신 배포본 (원본 복사)
│   ├── CMS_워크플로우_설명서_v1.docx
│   ├── CMS_콘텐츠독립성_아키텍처_정책문서_v1.docx
│   ├── CMS_DB스키마_설계서.md
│   ├── CMS_속성분리_설계서.md
│   ├── CMS_필드관리_설계서.md
│   ├── DESIGN.md                   ← 디자인 시스템 가이드 (AI 에이전트용)
│   ├── CLAUDE.md                   ← 이 파일
│   └── tasks/
│       ├── workflow.md             ← 워크플로우 설계 (계획 모드, 서브에이전트, 검증 등)
│       ├── todo.md                 ← 작업 추적 (진행/완료/대기)
│       └── lessons.md              ← 교훈 기록 (실수 패턴, 자기개선 루프)
```

### 편집-배포 워크플로우

1. `cms_prototype.html` 에서 편집
2. JS 검증: `sed -n '/<script>/,/<\/script>/p' cms_prototype.html | sed '1s/<script>//' | sed '$s/<\/script>//' > /tmp/_js_check.js && node --check /tmp/_js_check.js`
3. 배포: `cp cms_prototype.html mnt/Prototype/cms_stg_prd_v7.html`

---

## 워크플로우 & 작업 관리

`tasks/workflow.md`에 전체 워크플로우 설계가 정의되어 있다. **세션 시작 시 반드시 읽을 것.**

### 핵심 규칙 요약
1. **계획 먼저** — 3단계 이상 작업은 계획 모드로 시작, `tasks/todo.md`에 기록
2. **서브에이전트 활용** — 조사/탐색/병렬 분석은 서브에이전트에 위임
3. **자기개선 루프** — 수정 받을 때마다 `tasks/lessons.md`에 교훈 기록
4. **완료 전 검증** — "시니어 엔지니어가 승인할까?" 자문 후 완료 표시
5. **우아함 추구** — 사소하지 않은 변경은 더 나은 방법 고민, 단 오버엔지니어링 금지
6. **자율적 버그 수정** — 버그는 물어보지 말고 직접 해결

### 핵심 원칙
- **단순함 우선**: 건드리는 코드 최소화
- **게으름 금지**: 근본 원인 해결, 임시방편 없음
- **최소 영향**: 꼭 필요한 부분만 수정

### 에이전트 역할 정의 (경량 팀 — 단일 에이전트 내 모드 전환)

프로토타입 단계이므로 별도 에이전트를 분리하지 않고, **하나의 에이전트가 3가지 역할을 모드 전환**하여 수행한다.

| 역할 | 담당 | 트리거 |
|------|------|--------|
| **UI 프로토타이퍼** | HTML/JS/CSS 구현, 뷰 렌더링, 인터랙션 | 화면 구현·수정·레이아웃 변경 요청 |
| **아키텍트** | 데이터 구조 설계, DB 스키마, 워크플로우 흐름 | 구조 변경·데이터 모델·프로세스 설계 요청 |
| **검증자** | JS 문법 검증, UI 일관성, DESIGN.md 준수, 교차 영향 점검 | 모든 구현 완료 후 자동 실행 |

#### 역할별 체크포인트
- **UI 프로토타이퍼**: DESIGN.md 참조 → 인라인 스타일 → 문자열 연결(백틱 금지) → var 선언
- **아키텍트**: CLAUDE.md 데이터 구조 참조 → ncm_ prefix → 콘텐츠 독립성 원칙 준수
- **검증자**: JS syntax check → 사이드바 메뉴 정합성 → 데이터 흐름 교차 점검 → CLAUDE.md 동기화

#### 스케일 모드
- **풀 파이프라인**: 새 뷰 추가, 대형 구조 변경 → 3역할 모두 순차 실행
- **축소 모드**: 기존 뷰 수정, 버그 수정 → UI 프로토타이퍼 + 검증자
- **단일 모드**: 텍스트 수정, 오타 교정, 문서 업데이트 → 해당 역할만

---

## 디자인 시스템 (DESIGN.md)

프로젝트 루트에 `DESIGN.md` 파일이 있으며, CMS 프로토타입의 시각 디자인 시스템을 정의한다.
[awesome-design-md](https://github.com/VoltAgent/awesome-design-md) 형식을 따르며, AI 에이전트가 이 파일을 참조하여 일관된 UI를 생성할 수 있다.

### DESIGN.md 활용 규칙
- **새 뷰/컴포넌트 생성 시 반드시 DESIGN.md를 참조**하여 색상, 타이포그래피, 컴포넌트 스타일을 일관되게 유지
- CSS 변수(`var(--c-*)`)를 사용할 것 — 하드코딩 지양
- 타겟 시스템 배지(ND/NH/SJ/NH365)는 `WC_SYSTEM_COLORS` 및 DESIGN.md의 Target System Colors 섹션 참조
- 9개 섹션: Visual Theme → Color Palette → Typography → Components → Layout → Depth → Do's/Don'ts → Responsive → Agent Prompt Guide

---

## 코딩 컨벤션

### 필수 규칙
- **helper 함수 내에서 template literal(백틱) 사용 금지** → 반드시 문자열 연결(`+`) 사용
- **한글 문자열은 유니코드 이스케이프 사용** (`'\uD64D\uAE38\uB3D9'` 등) — 특히 Python patch 스크립트에서
- **변수 선언은 `var`** 사용 (helper 함수 내부). 상위 스코프 상수는 `const` 허용
- **CSS는 인라인 style** (외부 CSS 파일 없음, `<style>` 블록은 파일 상단에 존재)
- **대형 변경은 Python patch 스크립트** 작성 후 실행 (직접 편집이 어려운 경우)

### 함수 네이밍 패턴
- `render{ViewName}View()` — 최상위 뷰 렌더링
- `_render{Section}()` — 내부 섹션 렌더링 (private)
- `_{prefix}{Action}()` — 뷰별 인터랙션 핸들러 (예: `_wcToggleTemplate`, `_deployCreateRevision`)

---

## 아키텍처: 뷰 & 네비게이션

### 사이드바 메뉴 구조 (v7 — 기능 그룹 기반)

```
작업 진행 보드              → switchView('workflow')          [칸반 보드, 최상위 메뉴]

콘텐츠 작업
├── 작업 설정               → switchView('work-config')       [커리큘럼 단위 작업 배정]
└── 콘텐츠 등록             → switchView('content-register')  [실제 콘텐츠 등록 작업]

검수 & 배포
├── 검수 관리               → switchIAView('review-main')
└── 배포 관리               → switchView('deploy')             [바인딩 완료 콘텐츠만 배포]

서비스 연결 관리
├── 과목코드 바인딩         → switchView('service-bind')      [커리큘럼↔과목코드 매핑]
└── 서비스 콘텐츠 관리      → switchView('service-content')    [배포 완료 콘텐츠 관리]

양식 관리
├── 입력 양식 관리          → switchView('form-manage')       [필드 양식 정의]
└── 커리큘럼 관리           → switchView('curriculum')        [depth·양식 매핑, 트리 에디터]

설정
└── 시스템 관리             → switchIAView('settings')
```

**페이지별 디테일 (v7.1)**: 각 뷰 상단에 워크플로 Step Indicator 브레드크럼, 하단에 이전/다음 단계 CTA 렌더링. 사이드바 구조와는 독립적인 페이지 내 동선 보조 UI. 양식 배지/커리큘럼명 클릭 시 관련 뷰로 점프.

### ALL_VIEWS 배열
```javascript
const ALL_VIEWS = [
  'dashboard', 'course-list', 'structure', 'content', 'review',
  'deploy', 'service-content', 'settings', 'workorder', 'live-content',
  'answer-editor', 'batch-receive', 'workflow', 'work-config',
  'type-mapping', 'service-dist', 'bundle-hub', 'content-register',
  'code-manage', 'learning-type',
  'form-manage', 'curriculum', 'service-bind'  // v7 신규
];
```

---

## 핵심 헬퍼 함수

### _wcGetDepthTotal(rt, code, splitLevel)
템플릿 Depth 구조에서 총 작업 수량을 계산하는 중앙 헬퍼.
Work-config 카드 표시, 범위 분할 등에서 단일 진실 소스(single source of truth)로 사용.

```javascript
function _wcGetDepthTotal(rt, code, splitLevel) {
  // 1) LT_STATE.types의 depth 구조에서 groupCount 조회
  // 2) splitLevel 또는 rt.splitDepth로 분할 레벨 결정
  // 3) fallback: SUBJECT_COURSE_DATA[code].sets
  return { total: N, name: '세트', source: 'depth'|'legacy' };
}
```

- **splitLevel**: 작업 분할이 일어나는 depth 레벨 (예: 2=세트)
- **groupCount 의미**: 해당 depth 레벨의 전체 항목 수 (예: 과목=1, 과정=8, 세트=80)
- **사용처**: `_wcAddDepthRange`, `_wcAddRange`, work-config 카드 패널

### _ltToggleTargetSystem(typeId, sysKey)
콘텐츠 템플릿 관리 Step1에서 연계 시스템 멀티선택 토글.

```javascript
function _ltToggleTargetSystem(typeId, sysKey) {
  // t.targetSystems 배열에서 sysKey를 추가/제거
  // 2개 이상 선택 시 경고: "콘텐츠가 동일하지 않을 경우 하나의 시스템만 선택하세요!"
}
```

---

## 핵심 데이터 구조

### WF_ITEMS (워크플로우 아이템)
```javascript
{
  id: 'wf1a',
  templateName: '뉴드림스 해답지/채점/평가',
  typeCode: 'ANS',              // 콘텐츠 유형 코드
  target: 'ND',                 // 타겟 시스템: ND(뉴드림스), NH(눈높이), SJ(성장판)
  subject: '수학',
  subjectCode: 'M',
  course: '기초수학',
  phase: 'register',            // register | review | deploy
  assignee: '홍길동',
  priority: 'normal',           // normal | high | urgent
  source: 'batch',              // batch(외부연동) | manual(직접등록)
  currSrc: 'origin',            // origin(원본활용) | remix(재구성) | create(자체생성)
  setProgress: [{set:'1세트', status:'done'}, ...],
  doneCount: 1,
  totalCount: 4,
  bundleId: 'bnd1',             // 허브-스포크 번들 연결 (선택)
  bundleRole: 'hub',            // hub | spoke
}
```

### DEPLOY_STATE
```javascript
var DEPLOY_STATE = {
  schedules: [...],             // 배포 스케줄 목록
  history: [{                   // 배포 이력
    id: 'D001',
    deployedItems: [{           // 배포된 개별 콘텐츠
      wfId, templateName, typeCode, target, subject, course,
      assignee, version, deployDate, patchNote
    }]
  }],
  selectedStg: new Set(),
  activeScheduleId: null,
  showNewSchedule: false,
  stgExpanded: false,           // STG 알림바 펼침/접기
  prdTab: 'schedule',
  historySearch: '',
  historyFilter: 'all',
  expandedDeployId: null,
};
```

### SVC_STATE (서비스 콘텐츠)
```javascript
var SVC_STATE = {
  search: '',
  filterSubject: 'all',
  filterTarget: 'all',
  filterDeploy: 'all',
  filterDist: 'all',            // all | internal | external | both
  sortBy: 'date-desc',
  page: 1,
  perPage: 20,
};
```

### WC_STATE (콘텐츠 작업 설정)
```javascript
const WC_STATE = {
  searchQuery: '',
  filterStatus: 'all',
  selectedCode: null,
  expandedTemplate: null,       // 'M-0' 형식: 과목코드-템플릿인덱스
};
```

### REGISTERED_WORK_TYPES (과목별 템플릿 배정)
```javascript
var REGISTERED_WORK_TYPES = {
  M: [
    {
      name: '정답·해설 (뉴드림스)',
      typeCode: 'ANS',
      target: 'ND',
      assignee: '홍길동',
      currSrc: 'origin',                    // origin | remix | create
      splitDepth: 2,                        // ★ 분할 레벨 (세트=2)
      ltTypeId: 'type_ans',                 // ★ LT_STATE.types 연결 ID
      setRanges: [                          // 원본활용일 때: 세트 범위 분할
        {from:1, to:40, assignee:'홍길동'},
        {from:41, to:80, assignee:'김철수'},
      ]
    },
    {
      name: '눈높이 내신완공 영상강의',
      typeCode: 'STDG',
      target: 'NH',
      assignee: '홍길동',
      currSrc: 'remix',                     // 재구성 패턴
      ltTypeId: 'type_stdg',               // ★ LT_STATE.types 연결 ID
      customCurriculum: {                   // remix/create일 때: 자체 커리큘럼
        label: '출판사별 강좌 커리큘럼',
        unitName: '강',
        groups: [
          {name:'천재 중1-1', units:['OT','1강','2강',...], assignee:'홍길동'},
          {name:'미래엔 중1-1', units:['OT','1강',...], assignee:'이영희'},
        ]
      }
    },
  ],
};
```

### LT_STATE.types (콘텐츠 템플릿 — 신규 필드)
```javascript
{
  id: 'type_ans',
  name: '해답지·채점·평가',
  code: 'ANS',
  targetSystems: ['ND'],                  // ★ 연계 시스템 멀티선택
  structureName: '해답지 표준 구조',        // ★ depth 구조 이름
  depths: [
    {name:'과목', groupCount:1},
    {name:'과정', groupCount:8},
    {name:'세트', groupCount:80},          // groupCount = 해당 레벨 전체 항목 수
    {name:'학습일', groupCount:400},
  ]
}
```
- **`targetSystems`**: Step1(구조 기본정보)에서 멀티선택, WC_SYSTEM_COLORS 키 배열
- **`groupCount`**: 해당 depth 레벨의 전체 항목 수 (누적 곱이 아님)
- **`splitDepth`**: REGISTERED_WORK_TYPES에서 작업 분할이 일어나는 레벨 인덱스

### v7 신규 데이터 구조

#### CURRICULUM_DATA (커리큘럼 정의)
```javascript
var CURRICULUM_DATA = [
  {id:'CUR-001', name:'수학 기초 과정', desc:'뉴드림스 수학 기초 커리큘럼',
   formIds:['FORM-ANS-A','FORM-AN2-A'],     // 연결된 입력 양식
   depths:[{name:'과목',count:1},{name:'과정',count:8},{name:'세트',count:80},{name:'학습일',count:400}],
   splitDepth:2,                             // 작업 분할 레벨 (세트)
   status:'active',                          // active | draft
   boundCodes:['M'],                         // 바인딩된 과목코드 (빈 배열 = 미바인딩)
   bindConfig:{'M':{mode:'full'}},           // ★ 코드별 바인딩 설정
   totalSets:80},
];
```
- **`bindConfig`**: 과목코드별 바인딩 범위 설정
  - `mode: 'full'` — 커리큘럼 전체 범위 바인딩
  - `mode: 'partial'` + `depthRanges: [null, {from:1,to:4}, null]` — depth 레벨별 부분 범위
  - `depthRanges[i]`가 `null`이면 해당 depth는 전체 적용, 객체면 범위 제한
  - DB 매핑: `ncm_content_bindings.bind_mode`, `ncm_bind_depth_ranges (binding_id, depth_idx, range_from, range_to)`

#### FORM_TEMPLATES (입력 양식 정의)
```javascript
var FORM_TEMPLATES = [
  {id:'FORM-ANS-A', name:'정답·해설 입력 양식', code:'ANS-A', fieldCount:5,
   fields:['문항번호','정답','배점','해설','비고'], status:'active', usedIn:2},
];
```
- DB 매핑: `ncm_form_templates` → `field_pool` + `type_fieldsets`

#### WORK_ITEMS_V7 (커리큘럼 기반 작업 아이템)
```javascript
var WORK_ITEMS_V7 = [
  {id:'WI-001', curriculumId:'CUR-001', formId:'FORM-ANS-A', formName:'정답·해설',
   currName:'수학 기초 과정', assignee:'홍길동', rangeFrom:1, rangeTo:40,
   totalSets:40, doneSets:28, status:'inprog',
   boundCode:'M', boundLabel:'수학'},         // null = 미바인딩
];
```
- DB 매핑: `ncm_work_assignments` (curriculum_id, form_id, assignee, range_from, range_to)

#### BIND_STATE (과목코드 바인딩)
```javascript
var BIND_STATE = { search:'', filterStatus:'all', selectedCurId:null };
```

### SUBJECT_COURSE_DATA (과목 메타)
```javascript
const SUBJECT_COURSE_DATA = {
  M:  {courseName:'수학', courses:8, sets:80},
  E:  {courseName:'영어', courses:6, sets:60},
  K:  {courseName:'국어', courses:5, sets:50},
  // ... 29개 과목코드
};
```

### SUBJECT_TYPE_MAP (과목별 유형 매핑)
```javascript
const SUBJECT_TYPE_MAP = {
  M:  {name:'수학', children:['MV'], types:['ANS','AN2','AN3','CBT','STDG']},
  E:  {name:'영어', children:[], types:['AN2','AN3','CBT','CCV','CGL','EVA','FLC','WEB']},
  // ...
};
```

---

## 콘텐츠 독립성 아키텍처 (v7 핵심 변경)

### 핵심 개념
콘텐츠는 과목코드와 **완전히 독립적으로** 존재하며, 바인딩을 통해 연결된다.
v7부터 과목코드 의존성을 제거하고, 커리큘럼 중심 워크플로우로 전환.

### 유형코드와 과목코드 바인딩 — 용어 정의

- **유형코드 (Type Code)**: 커리큘럼 + 입력 양식이 확정되면 자동 생성되는 내부 식별자 (ANS, CBT 등). UI에 직접 노출할 필요 없음. DB에 저장되어 시스템 내부 분류에 사용.
- **과목코드 바인딩**: 완성된 커리큘럼 콘텐츠를 외부 시스템(뉴드림스, 눈높이 등)의 과목코드(M, E, K 등 300개+)와 연결하는 행위. 이 바인딩을 통해 동일 커리큘럼을 여러 시스템에 제공(판매)할 수 있는 구조가 된다.
- **바인딩의 의미**: 내부 콘텐츠 체계(커리큘럼)와 외부 서비스 체계(과목코드)를 분리함으로써, 하나의 콘텐츠를 자사 시스템뿐 아니라 타사 시스템에도 바인딩하여 제공할 수 있다.

### v7 프로세스 흐름
```
① 입력 양식 정의 → ② 커리큘럼 설계 → ③ 콘텐츠 제작 → ④ 과목코드 바인딩 → ⑤ 배포
```

- **① 입력 양식**: 양식 관리 > 입력 양식 관리 (field_pool + type_fieldsets)
- **② 커리큘럼**: 양식 관리 > 커리큘럼 관리 (depth 구조 + 양식 매핑 → 유형코드 자동 생성)
- **③ 콘텐츠 제작**: 작업 설정 → 콘텐츠 등록 (커리큘럼 단위 작업)
- **④ 과목코드 바인딩**: 서비스 연결 관리 > 과목코드 바인딩 (커리큘럼 ↔ 과목코드 300개+ 모달 검색)
- **⑤ 배포**: 검수 → 배포 관리 (바인딩 완료 콘텐츠만 대상)

### Work-config 카드 (v7 — 커리큘럼 기반)
과목코드 카드 대신 커리큘럼 카드로 전환:

```
┌─ 수학 기초 과정                     활성 ─┐
│  과목 1 › 과정 8 › [세트 80] › 학습일 400  │
│  바인딩 코드: [M 수학]                      │
│  입력 양식: [정답·해설] [자동채점]           │
│  전체 진행률: ███████░░░ 72%               │
│  ─────────────────────────────────        │
│  ■ 홍길동  정답·해설  1~40   ████░░ 70%    │
│  ■ 김철수  정답·해설  41~80  ██████ 100%   │
└──────────────────────────────────────────┘
```

- **바인딩 코드**: `CURRICULUM_DATA[].boundCodes` → 미바인딩 시 경고 표시
- **입력 양식**: `CURRICULUM_DATA[].formIds` → `FORM_TEMPLATES`에서 조회
- **담당자 배정**: `WORK_ITEMS_V7` 필터링하여 커리큘럼별 작업 표시

### 배포 대상
- 바인딩 완료된 커리큘럼만 배포 가능
- 내부 서비스 (뉴드림스/학습관/성장판)
- 외부 제공 (판매/제휴)

---

## 속성 스키마 (WC_ATTR_SCHEMA)

콘텐츠 작업 설정의 속성 팝업에서 사용:

```javascript
required: [
  curriculumSource  // 커리큘럼 소스: 원본활용/재구성/자체생성
  contentSource     // 콘텐츠 입력 방식: 과목>과정>세트 / 직접 등록
  distTarget        // 배포 대상: 내부 서비스 / 외부 제공 / 내부+외부
  detailTypes       // 세부 구분 목록
  dayRange          // 학습일 범위
  fileAccept        // 허용 파일 형식
  requiredFields    // 필수 입력 항목
]
optional: [
  seqStart, autoFields, namingRule, maxFileSize, customMemo
]
```

---

## 타겟 시스템 컬러 코드

```javascript
const WC_SYSTEM_COLORS = {
  ND:    {bg:'#E8F2FF', color:'#0055B8', border:'#B3D7FF', label:'뉴드림스'},
  NH:    {bg:'#F9F0FF', color:'#8944AB', border:'#D9B3F0', label:'눈높이'},
  SJ:    {bg:'#F0FFF4', color:'#1B8A3E', border:'#A8E6B8', label:'성장판'},
  NH365: {bg:'#FFF8F0', color:'#B35C00', border:'#FFD9A8', label:'눈높이365'},
};
```

---

## 배포 관리 구조

### STG (스테이징)
- 접을 수 있는 알림바 형태 (대부분 비어있으므로)
- `stgExpanded: false` — 펼치면 배포 대기 아이템 표시
- pulse 애니메이션으로 대기 건수 알림

### PRD (프로덕션)
- 배포 스케줄 관리 (스케줄 카드)
- 배포 이력은 별도 "서비스 콘텐츠" 메뉴로 분리됨

### 수정 배포 프로세스
배포 완료 콘텐츠 수정 시:
1. 서비스 콘텐츠에서 검색
2. "수정 작업 생성" → 새 워크플로우 아이템 생성 (version 증가)
3. 수정 → 검수 → 배포 프로세스 재진행

---

## 눈높이 내신완공 (NH STDG) 특수 구조

내신완공은 일반 세트 구조가 아닌 강좌 단위:
- 출판사별 그룹 (천재, 미래엔, 비상 등)
- 각 그룹 안에 OT + N개 강
- `NH_SAMPLE_FIELDS` — 영상강의 전용 필드 정의
- `NH_SAMPLE_DATA` — 샘플 데이터 (오리엔테이션, 1강~...)
- 풀스크린 편집기에서 서브탭/출판사/DRM 등 고유 속성 지원

---

## 워크플로우 보드 (칸반)

### 페이즈 구조
```
assign(담당 배정) → register(콘텐츠 등록) → review(검수) → deploy(배포)
```

### 카드 표시 요소
1. 시스템 배지 (ND/NH/SJ)
2. 유형코드 (ANS/CBT/FLC/STDG...)
3. 우선순위 (긴급 시 빨간 뱃지)
4. 허브 표시 (MAIN 뱃지 — 번들 허브)
5. **소스 배지** (외부 연동 파란색 / 직접 등록 초록색)
6. 템플릿명
7. 과목코드 + 과정명
8. 진행률 바 (세트 기준)
9. 담당자 + 액션 버튼

### 풀스크린 편집기
- 헤더에 소스 타입 + 서비스코드 바인딩 표시
- 직접 등록: 서비스코드 선택 가능 (`_showCodeSelector()`)
- 외부 연동: "자동 바인딩" 표시
- 목록/편집/미리보기 3가지 뷰 전환
- 다크모드 지원

---

## 허브-스포크 번들

하나의 "과정"에 여러 유형의 콘텐츠가 묶이는 구조:
- Hub: 메인 콘텐츠 (MAIN 뱃지)
- Spoke: 연결된 하위 콘텐츠
- `bundleId`로 연결, `bundleRole`로 역할 구분

---

## 산출물 체계

### 산출물 생성 파이프라인 (Harness 패턴 차용)

작업 유형에 따라 산출물이 순차적으로 생성된다. 각 단계는 이전 산출물에 의존한다.

```
프로토타입 작업:  요구사항 확인 → 데이터 구조 설계 → UI 구현 → 검증 → 배포 → 문서 동기화
산출물 문서 작업:  프로토타입 분석 → 초안 작성 → 검토/수정 → mnt/Prototype/ 배포
```

### 산출물 목록

| 순서 | 파일 | 용도 | 생성 시점 |
|------|------|------|-----------|
| 00 | `cms_stg_prd_v7.html` | 인터랙티브 프로토타입 (단일 진실 소스) | 매 작업 완료 시 |
| 01 | `CMS_워크플로우_설명서_v1.docx` | 전체 업무 프로세스 설명서 | 프로세스 확정 후 |
| 02 | `CMS_콘텐츠독립성_아키텍처_정책문서_v1.docx` | 콘텐츠-코드 분리 아키텍처 정책 (Confluence용) | 아키텍처 확정 후 |
| 03 | `CMS_DB스키마_설계서.md` | DB 스키마 설계 | 데이터 구조 확정 후 |
| 04 | `CMS_속성분리_설계서.md` | 속성 분리 설계 | 속성 체계 확정 후 |
| 05 | `CMS_필드관리_설계서.md` | 필드 관리 설계 | 양식 체계 확정 후 |
| 06 | `CMS_v7_Release_Note.docx` | v7 개발자 릴리스 노트 | 버전 릴리스 시 |

### 산출물 버전 규칙
- 프로토타입: `cms_stg_prd_v{N}.html` — 메이저 변경 시 N 증가
- 문서: `{문서명}_v{N}.docx` — 내용 확정 시 N 증가
- **프로토타입이 변경되면 관련 문서도 동기화 필요 여부 점검** (변경 이력 참조)

---

## 변경 이력 (최근)

1. **배포 관리 STG/PRD 분리** — STG를 접을 수 있는 알림바로 변경, PRD에 스케줄 집중
2. **서비스 콘텐츠 메뉴 분리** — 배포 이력 + 검색 + 수정 작업을 독립 메뉴로
3. **콘텐츠 독립성 반영** — source 배지, 서비스코드 바인딩 UI, _showCodeSelector
4. **세트 범위 분할** — 작업 설정에서 템플릿별 세트 범위 분할 기능
5. **커리큘럼 소스 3분류** — origin(원본활용)/remix(재구성)/create(자체생성)
6. **내신완공 재구성 패턴** — customCurriculum 구조로 자체 커리큘럼 표현
7. **배포 대상 확장** — 내부 서비스 외 외부 제공/판매 옵션 추가
8. **중앙 헬퍼 함수 도입 (v5~)** — `_wcGetDepthTotal`로 depth 구조 기반 총량 계산을 단일 소스로 통합
9. **연계 시스템 멀티선택 (v5~)** — 템플릿 관리 Step1에 `targetSystems` 배열 추가, 멀티선택 토글 UI
10. **Work-config 카드 간소화 (v6)** — 복잡한 다행 구조를 심플 카드(시스템배지+커리큘럼합산+담당자프로그레스바)로 대체
11. **Depth 기반 데이터 흐름 (v6)** — `SUBJECT_COURSE_DATA.sets` 하드코딩 대신 `LT_STATE.types[].depths[].groupCount`를 진실 소스로 사용
12. **미등록 과목 통계 제거 (v6)** — 템플릿 미선택 과목에서 과목코드/과정/세트 숫자 표시 제거 (데이터 근거 없음)
13. **v7 콘텐츠 독립성 완성** — 과목코드 의존성 제거, 커리큘럼 중심 워크플로우 전환
14. **입력 양식 관리 신규 (v7)** — 설정 메뉴에 `form-manage` 뷰 추가, FORM_TEMPLATES 데이터
15. **커리큘럼 관리 신규 (v7)** — 설정 메뉴에 `curriculum` 뷰 추가, CURRICULUM_DATA 데이터, depth 구조 + 양식 매핑
16. **과목코드 바인딩 신규 (v7)** — 서비스 연결 관리 메뉴에 `service-bind` 뷰 추가, 모달 검색 UI (300+코드 대응)
17. **Work-config 커리큘럼 전환 (v7)** — 과목코드 카드 → 커리큘럼 카드, WORK_ITEMS_V7 데이터 기반
18. **콘텐츠 등록 3탭 필터 (v7)** — 전체/내 작업/팀 콘텐츠 3탭 필터 도입
19. **전 뷰 개발자 annotation (v7)** — 모든 키 스크린에 v7 DEV 박스 추가 (DB 테이블, 프로세스 안내)
20. **DB prefix ncm_ 확정 (v7)** — 회의 결정사항: 모든 신규 테이블 `ncm_` prefix 사용
21. **사이드바 메뉴 재구성 (v7)** — 서비스 콘텐츠를 서비스 연결 관리로 이동, 과목 코드 관리 통합 제거
22. **Harness 패턴 부분 차용 (v7)** — 경량 에이전트 역할 정의(3역할 모드 전환), 트리거 경계, 테스트 시나리오 3종, 에러 처리 전략, 의존성 DAG, 품질 체크리스트, 산출물 파이프라인 도입
23. **사이드바 활동 순서 재정렬 (v7.1, 2026-04-16 롤백)** — 사용자 활동 흐름 기반 4 그룹 + ①~⑦ 단계 번호 시도 → 사용자 피드백으로 v7 기능 그룹(콘텐츠 작업 / 검수·배포 / 서비스 연결 관리 / 양식 관리 / 설정) 구조로 **복원**. 메뉴 재정렬은 불필요, 페이지별 디테일만 유지.
24. **Step Indicator 공용 헬퍼 (v7.1, 페이지 디테일로 유지)** — `WORKFLOW_STEPS`, `_renderStepIndicator(currentView)`, `_renderStepCta(currentView)`. form-manage, curriculum, work-config, content-register 4개 뷰 상단/하단에 일관 주입. 사이드바와 독립된 페이지 내 워크플로 보조 UI.
25. **뷰 간 상호 링크 (v7.1, 유지)** — `_jumpToForm(formId)`, `_jumpToCurriculum(curId)`, `_jumpToWorkConfig(curId)` 헬퍼. 양식 배지 클릭 → form-manage 하이라이트 스크롤, 커리큘럼명 클릭 → curriculum 점프. `.xlink` CSS 클래스.
26. **제작 구간 세부 보강 (v7.1, 유지)** — FORM_TEMPLATES 6→8개 확장(AN3-A, EVA-A 추가) + `updatedAt`·`author` 메타 필드, form-manage empty state + 편집 alert, work-config 미바인딩/미연결 경고 chip.
27. **과목코드 부분 바인딩 (v7.2)** — 코드별 전체/부분 적용 모드 + depth 레벨별 범위(from/to) 토글 UI. `bindConfig` 객체 도입 (`{mode:'full'|'partial', depthRanges:[...]}`). 바인딩 배지 클릭 → 인라인 확장 패널. DB: `ncm_content_bindings.bind_mode`, `ncm_bind_depth_ranges`.
28. **입력 양식 편집기 (v7.2)** — `FM_EDIT_STATE` + `_fmRenderEditor` 분할 패널 UI. 왼쪽 필드 풀 브라우저(LT_FIELD_POOL 카테고리 필터) + 오른쪽 양식 구성. 같은 필드 중복 추가 후 타이틀 변형 가능 (`fieldDefs: [{poolKey, title, required}]`). 운영최고 담당자 전용 표시. DB: `ncm_form_field_defs (form_id, pool_key, display_title, sort_order, required)`.

---

## 주의사항 & 알려진 이슈

- 파일이 1MB 이상이므로 대형 변경 시 Python patch 스크립트 권장
- `switchView('service-dist')` → `switchView('deploy')`로 리다이렉트 처리됨 (레거시 호환)
- 일부 뷰(`batch-receive`, `bundle-hub`)는 스텁 상태
- `SUBJECT_TYPE_MAP`의 children 코드는 이름 매핑이 불완전할 수 있음
