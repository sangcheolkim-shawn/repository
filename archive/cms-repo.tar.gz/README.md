# CMS 고도화 프로토타입

대교 교육 콘텐츠 관리 시스템(CMS) 고도화 프로젝트 인터랙티브 프로토타입.

## 바로 보기

**GitHub Pages**: 이 레포의 Settings > Pages에서 `main` 브랜치 / `/ (root)` 선택 후 Save하면 URL이 생성됩니다.

## 파일 구조

| 파일 | 설명 |
|------|------|
| `index.html` | GitHub Pages 진입점 (= 최신 프로토타입) |
| `cms_stg_prd_v7.html` | 프로토타입 원본 (v7.2) |
| `CLAUDE.md` | AI 에이전트 프로젝트 컨텍스트 |
| `DESIGN.md` | 디자인 시스템 가이드 |
| `tasks/` | 작업 추적 (todo, lessons, workflow) |
| `CMS_*.md` | DB 스키마, 속성분리, 필드관리 설계서 |

## 현재 버전 (v7.2)

- 콘텐츠 독립성 아키텍처 (커리큘럼 중심 워크플로우)
- 입력 양식 편집기 (필드 풀 브라우저 + 타이틀 변형 중복 추가)
- 과목코드 부분 바인딩 (depth별 범위 지정)
- Step Indicator 워크플로 내비게이션
- 뷰 간 크로스링크 (양식↔커리큘럼↔작업설정)
