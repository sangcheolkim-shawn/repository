# TODO — CMS 프로토타입 프로젝트

> 현재 진행 중인 작업과 완료된 작업을 추적한다.

---

## 완료된 작업

### 2026-04-03 — Confluence 기획서 완성
- [x] [기능] 콘텐츠 작업 설정 페이지 재작성 (비즈니스 로직 중심)
- [x] [기능] 작업 진행 보드 페이지 재작성
- [x] [기능] 콘텐츠 등록 페이지 재작성
- [x] [기능] 배포 관리 및 서비스 콘텐츠 페이지 재작성
- [x] [기능] 검수 관리 페이지 생성
- [x] [기능] 과목 코드 관리 페이지 생성
- [x] [기능] 콘텐츠 템플릿 관리 페이지 생성
- [x] [기능] 학습 유형 설계 페이지 생성
- [x] [기능] 연계 시스템 페이지 생성
- [x] [기능] 시스템 관리 페이지 생성
- [x] 메뉴별 기능 명세 개요 페이지 업데이트 (업무 흐름 기반)

### 2026-04-03 — Apple 디자인 적용
- [x] DESIGN.md 생성 (awesome-design-md 9섹션 형식)
- [x] DESIGN.md → Apple HIG 스타일로 재작성
- [x] 프로토타입 CSS 변수 Apple 팔레트로 교체
- [x] 사이드바 글래스 모피즘 적용
- [x] WC_SYSTEM_COLORS Apple 톤으로 변경
- [x] CLAUDE.md에 DESIGN.md 참조 추가
- [x] 사이드바 가독성 개선 (배경 밝게 + 텍스트 불투명도 상향)

### 2026-04-03 — 워크플로우 체계 수립
- [x] tasks/workflow.md 생성
- [x] tasks/lessons.md 생성 (이번 세션 교훈 4건 기록)
- [x] tasks/todo.md 생성 (이 파일)

---

## 진행 중

(없음)

---

### 2026-04-16 — v7.1 페이지별 디테일 보강 (사이드바 롤백)
- [~] ~~사이드바 메뉴 재정렬 (①~⑦ 단계 번호)~~ → **v7 기능 그룹 구조로 롤백** (사용자 피드백: 페이지 디테일만 필요)
- [x] Step Indicator 공용 헬퍼 (`_renderStepIndicator`, `_renderStepCta`, `WORKFLOW_STEPS`) 도입 — 유지
- [x] 제작 구간 4개 뷰 상단 브레드크럼 + 하단 이전/다음 단계 CTA 주입 — 유지
- [x] 뷰 간 상호 링크 헬퍼 (`_jumpToForm`, `_jumpToCurriculum`, `_jumpToWorkConfig`) 도입 + 양식 배지·커리큘럼명 점프 — 유지
- [x] FORM_TEMPLATES 8개로 확장 + `updatedAt`·`author` 메타 필드 추가 — 유지
- [x] form-manage empty state, 편집 alert, 미연결 경고 칩 — 유지
- [x] work-config 카드 미바인딩 chip → service-bind 점프 — 유지
- [x] 4개 render 함수 div 균형 검증 통과 (25/25, 20/20, 40/40, 10/10)
- [x] CLAUDE.md 사이드바 섹션 v7 원복 + 변경 이력 #23 롤백 표기
- [x] lessons.md L9 추가 ("동선 정리" 요청 범위 확장 금지)

---

## 대기 중 / 향후 작업

- [ ] Step Indicator를 검수 · 배포 구간 뷰(review-main, service-bind, deploy)에도 주입 (현재 제작 구간만 적용, 필요시)
- [ ] 프로토타입 신규 뷰 개발 (batch-receive, bundle-hub 등 스텁 상태 뷰)
- [ ] Confluence 정책 문서 정비 (커리큘럼 소스, 콘텐츠 독립성 등)
- [ ] 대시보드 뷰 기획서 작성 (Confluence)
